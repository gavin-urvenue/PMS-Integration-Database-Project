create definer = urvenue@`%` trigger RESERVATIONlibProperty_table_update
    before update
    on RESERVATIONlibProperty
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

