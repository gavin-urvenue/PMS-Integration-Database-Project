create definer = urvenue@`%` trigger CUSTOMERlibLoyaltyProgram_table_update
    before update
    on CUSTOMERlibLoyaltyProgram
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

