create definer = urvenue@`%` trigger SERVICESlibServiceItems_table_update
    before update
    on SERVICESlibServiceItems
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

