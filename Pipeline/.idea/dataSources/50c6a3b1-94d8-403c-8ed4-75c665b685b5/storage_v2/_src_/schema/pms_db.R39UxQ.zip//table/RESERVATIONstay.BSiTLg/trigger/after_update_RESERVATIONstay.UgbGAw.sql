create definer = root@localhost trigger after_update_RESERVATIONstay
    after update
    on RESERVATIONstay
    for each row
BEGIN
  INSERT INTO RESERVATIONstay_audit (operationType, operatedBy, idAudit, statusAudit, rndCodeAudit, createTStampAudit, modTStampAudit, createDateTime, modifyDateTime, startDate, endDate, createdBy, metaData, extPMSConfNum, extGuestId, dataSource, libSourceId, libPropertyId)
  VALUES ('UPDATE', USER(), NEW.id, NEW.status, NEW.rndCode, NEW.createTStamp, NEW.modTStamp, NEW.createDateTime, NEW.modifyDateTime, NEW.startDate, NEW.endDate, NEW.createdBy, NEW.metaData, NEW.extPMSConfNum, NEW.extGuestId, NEW.dataSource, NEW.libSourceId, NEW.libPropertyId);
END;

