create definer = urvenue@`%` trigger RESERVATIONlibRoom_table_update
    before update
    on RESERVATIONlibRoom
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

