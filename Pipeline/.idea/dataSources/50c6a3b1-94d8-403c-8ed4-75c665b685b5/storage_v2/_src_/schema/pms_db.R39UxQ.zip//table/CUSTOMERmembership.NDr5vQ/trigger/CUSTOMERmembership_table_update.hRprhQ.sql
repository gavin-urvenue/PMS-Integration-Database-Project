create definer = urvenue@`%` trigger CUSTOMERmembership_table_update
    before update
    on CUSTOMERmembership
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

