create definer = urvenue@`%` trigger RESERVATIONgroup_table_update
    before update
    on RESERVATIONgroup
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

