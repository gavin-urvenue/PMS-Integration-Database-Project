create definer = urvenue@`%` trigger PMSDATABASEmisc_table_insert
    before insert
    on PMSDATABASEmisc
    for each row
BEGIN
    # DBLIB_VERSION=4
    DECLARE v_id BIGINT;
    CALL `dblib`.`insert_seq`('pms_db', 'PMSDATABASEmisc', v_id);
    SET NEW.id = v_id;
    SET NEW.rndcode = `dblib`.GenIdPass(v_id, 12, '');
    IF (NEW.`status` IS NULL) OR (NEW.`status` = 0) THEN
        SET NEW.`status` = 7;
    END IF;
    SET NEW.createtstamp = UNIX_TIMESTAMP();
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

