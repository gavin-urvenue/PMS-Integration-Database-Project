create definer = urvenue@`%` trigger SERVICESfolioOrders_table_update
    before update
    on SERVICESfolioOrders
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

