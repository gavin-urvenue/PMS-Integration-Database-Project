create definer = urvenue@`%` trigger RESERVATIONlibSource_table_update
    before update
    on RESERVATIONlibSource
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

