create definer = root@localhost trigger before_delete_RESERVATIONstay
    before delete
    on RESERVATIONstay
    for each row
BEGIN
  INSERT INTO RESERVATIONstay_audit (operationType, operatedBy, idAudit, statusAudit, rndCodeAudit, createTStampAudit, modTStampAudit, createDateTime, modifyDateTime, startDate, endDate, createdBy, metaData, extPMSConfNum, extGuestId, dataSource, libSourceId, libPropertyId)
  VALUES ('DELETE', USER(), OLD.id, OLD.status, OLD.rndCode, OLD.createTStamp, OLD.modTStamp, OLD.createDateTime, OLD.modifyDateTime, OLD.startDate, OLD.endDate, OLD.createdBy, OLD.metaData, OLD.extPMSConfNum, OLD.extGuestId, OLD.dataSource, OLD.libSourceId, OLD.libPropertyId);
END;

