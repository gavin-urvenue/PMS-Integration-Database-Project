create definer = root@localhost view vw_pms_data_all as
select `s`.`createDateTime`        AS `createDateTime`,
       `s`.`modifyDateTime`        AS `modifyDateTime`,
       `s`.`startDate`             AS `stayStartDate`,
       `s`.`endDate`               AS `stayEndDate`,
       `s`.`createdBy`             AS `createdBy`,
       `s`.`metaData`              AS `stayMetaData`,
       `s`.`extPMSConfNum`         AS `extPMSConfNum`,
       `s`.`extGuestId`            AS `extGuestId`,
       `s`.`dataSource`            AS `dataSource`,
       `rrc`.`className`           AS `className`,
       `rr`.`roomNumber`           AS `roomNumber`,
       `rrt`.`typeName`            AS `typeName`,
       `rrt`.`typeCode`            AS `typeCode`,
       `rss`.`status`              AS `status`,
       `rss`.`statusName`          AS `statusName`,
       `rs`.`sourceName`           AS `sourceName`,
       `rs`.`sourceType`           AS `sourceType`,
       `rp`.`chainCode`            AS `chainCode`,
       `rp`.`propertyCode`         AS `propertyCode`,
       `fo`.`amount`               AS `amount`,
       `fo`.`fixedChargesQuantity` AS `fixedChargesQuantity`,
       `fo`.`ratePlanCode`         AS `folioOrderRatePlanCode`,
       `fo`.`isIncluded`           AS `isIncluded`,
       `fo`.`startDate`            AS `folioOrderStartDate`,
       `fo`.`endDate`              AS `folioOrderEndDate`,
       `fo`.`folioOrderType`       AS `folioOrderType`,
       `fo`.`unitCount`            AS `unitCount`,
       `fo`.`unitPrice`            AS `unitPrice`,
       `fo`.`metaData`             AS `folioOrderMetaData`,
       `p`.`paymentAmount`         AS `paymentAmount`,
       `p`.`currencyCode`          AS `currencyCode`,
       `t`.`paymentMethod`         AS `paymentMethod`,
       `si`.`itemName`             AS `itemName`,
       `si`.`itemCode`             AS `itemCode`,
       `si`.`ratePlanCode`         AS `serviceItemRatePlanCode`,
       `c`.`firstName`             AS `firstName`,
       `c`.`lastName`              AS `lastName`,
       `c`.`title`                 AS `title`,
       `c`.`email`                 AS `email`,
       `c`.`birthDate`             AS `birthDate`,
       `c`.`languageCode`          AS `languageCode`,
       `c`.`languageFormat`        AS `languageFormat`,
       `c`.`extGuestId`            AS `customerGuestId`,
       `c`.`metaData`              AS `customerMetaData`,
       `r`.`isPrimaryGuest`        AS `isPrimaryGuest`,
       `ct`.`type`                 AS `type`,
       `m`.`level`                 AS `level`,
       `m`.`membershipCode`        AS `membershipCode`,
       `lp`.`name`                 AS `name`,
       `lp`.`source`               AS `source`
from (((((((((((((((((`pms_db`.`reservationstay` `s` left join `pms_db`.`reservationroomdetails` `rd`
                      on ((`s`.`id` = `rd`.`stayId`))) left join `pms_db`.`reservationlibroomclass` `rrc`
                     on ((`rd`.`libRoomClassId` = `rrc`.`id`))) left join `pms_db`.`reservationlibroom` `rr`
                    on ((`rd`.`libRoomId` = `rr`.`id`))) left join `pms_db`.`reservationlibroomtype` `rrt`
                   on ((`rd`.`libRoomTypeId` = `rrt`.`id`))) left join `pms_db`.`reservationstaystatusstay` `rsss`
                  on ((`s`.`id` = `rsss`.`stayId`))) left join `pms_db`.`reservationlibstaystatus` `rss`
                 on ((`rsss`.`stayStatusId` = `rss`.`id`))) left join `pms_db`.`reservationlibsource` `rs`
                on ((`s`.`libSourceId` = `rs`.`id`))) left join `pms_db`.`reservationlibproperty` `rp`
               on ((`s`.`libPropertyId` = `rp`.`id`))) left join `pms_db`.`servicesfolioorders` `fo`
              on ((`s`.`id` = `fo`.`stayId`))) left join `pms_db`.`servicespayment` `p`
             on ((`fo`.`paymentId` = `p`.`id`))) left join `pms_db`.`serviceslibtender` `t`
            on ((`p`.`libTenderId` = `t`.`id`))) left join `pms_db`.`serviceslibserviceitems` `si`
           on ((`fo`.`libServiceItemsId` = `si`.`id`))) left join `pms_db`.`customercontact` `c`
          on ((`fo`.`contactId` = `c`.`id`))) left join `pms_db`.`customerrelationship` `r`
         on ((`c`.`id` = `r`.`contactId`))) left join `pms_db`.`customerlibcontacttype` `ct`
        on ((`r`.`contactTypeId` = `ct`.`id`))) left join `pms_db`.`customermembership` `m`
       on ((`c`.`id` = `m`.`contactId`))) left join `pms_db`.`customerlibloyaltyprogram` `lp`
      on ((`m`.`libLoyaltyProgramId` = `lp`.`id`)));

