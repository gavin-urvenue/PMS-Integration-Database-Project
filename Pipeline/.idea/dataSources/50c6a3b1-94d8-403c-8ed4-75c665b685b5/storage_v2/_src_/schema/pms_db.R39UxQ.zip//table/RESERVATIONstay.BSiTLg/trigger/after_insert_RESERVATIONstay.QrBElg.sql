create definer = root@localhost trigger after_insert_RESERVATIONstay
    after insert
    on RESERVATIONstay
    for each row
BEGIN
  INSERT INTO RESERVATIONstay_audit (operationType, operatedBy, idAudit, statusAudit, rndCodeAudit, createTStampAudit, modTStampAudit, createDateTime, modifyDateTime, startDate, endDate, createdBy, metaData, extPMSConfNum, extGuestId, dataSource, libSourceId, libPropertyId)
  VALUES ('INSERT', USER(), NEW.id, NEW.status, NEW.rndCode, NEW.createTStamp, NEW.modTStamp, NEW.createDateTime, NEW.modifyDateTime, NEW.startDate, NEW.endDate, NEW.createdBy, NEW.metaData, NEW.extPMSConfNum, NEW.extGuestId, NEW.dataSource, NEW.libSourceId, NEW.libPropertyId);
END;

