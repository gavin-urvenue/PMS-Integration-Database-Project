create definer = urvenue@`%` trigger RESERVATIONroomDetails_table_update
    before update
    on RESERVATIONroomDetails
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

