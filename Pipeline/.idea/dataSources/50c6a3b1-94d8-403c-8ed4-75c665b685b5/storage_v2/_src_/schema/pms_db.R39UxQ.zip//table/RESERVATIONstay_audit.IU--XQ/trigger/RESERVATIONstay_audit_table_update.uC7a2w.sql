create definer = urvenue@`%` trigger RESERVATIONstay_audit_table_update
    before update
    on RESERVATIONstay_audit
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

