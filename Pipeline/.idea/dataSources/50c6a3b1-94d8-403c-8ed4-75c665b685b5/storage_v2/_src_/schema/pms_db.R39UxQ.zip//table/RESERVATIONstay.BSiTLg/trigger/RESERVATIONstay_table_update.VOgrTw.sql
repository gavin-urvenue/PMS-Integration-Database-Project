create definer = urvenue@`%` trigger RESERVATIONstay_table_update
    before update
    on RESERVATIONstay
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

