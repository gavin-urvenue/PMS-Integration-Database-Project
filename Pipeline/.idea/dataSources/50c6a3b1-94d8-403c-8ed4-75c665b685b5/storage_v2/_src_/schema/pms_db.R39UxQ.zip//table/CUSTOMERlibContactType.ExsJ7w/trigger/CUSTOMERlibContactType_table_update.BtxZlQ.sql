create definer = urvenue@`%` trigger CUSTOMERlibContactType_table_update
    before update
    on CUSTOMERlibContactType
    for each row
BEGIN
    # DBLIB_VERSION=4
    SET NEW.modtstamp = UNIX_TIMESTAMP();
END;

